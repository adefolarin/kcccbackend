<!DOCTYPE html>
<html>
<head>
    <title>KCCC</title>
</head>
<body>
    <h4>{{ $mailData['title'] }}</h4>
    <p>Date: {{ $mailData['membregs_date'] }}</p>
    <p>Name: {{ $mailData['membregs_name'] }}</p>
    <p>Email: {{ $mailData['membregs_email'] }}</p>
    <p>Phone Number: {{ $mailData['membregs_pnum'] }}</p>
    <p>Gender: {{ $mailData['membregs_gender'] }}</p>
    <p>Marital Status: {{ $mailData['membregs_maritalstatus'] }}</p>
    <p>Date Of Birth: {{ $mailData['membregs_dob'] }}</p>
    <p>How You Heard About US: {{ $mailData['membregs_how'] }}</p>
    <p>Reason For Joining: {{ $mailData['membregs_reason'] }}</p>
    <p>Are You Born Again?: {{ $mailData['membregs_bornagain'] }}</p>
    <p>Can we offer you guidnace?: {{ $mailData['membregs_guidance'] }}</p>
    <p>Payer Request: {{ $mailData['membregs_request'] }}</p>
    <p>Would like to receive news update and newsletter via email?: {{ $mailData['membregs_updated'] }}</p>

  
    <p></p>
     
</body>
</html>