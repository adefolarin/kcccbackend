<!DOCTYPE html>
<html>
<head>
    <title>KCCC / Request For Account Deletion</title>
</head>
<body>
    <h4>{{ $mailData['title'] }}</h4>
    <p>Name: {{ $mailData['delaccs_name'] }}</p>
    <p>Email: {{ $mailData['delaccs_email'] }}</p>
    <p>Date: {{ $mailData['delaccs_date'] }}</p>  
     
</body>
</html>