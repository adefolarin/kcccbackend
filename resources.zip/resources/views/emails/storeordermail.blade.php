<!DOCTYPE html>
<html>
<head>
    <title>KCCC</title>
</head>
<body>
    <h4>{{ $mailData['title'] }}</h4>

     
    <p>Thank you</p>
</body>
</html>