<!DOCTYPE html>
<html>
<head>
    <title>KCCC</title>
</head>
<body>
    <h4>{{ $mailData['title'] }}</h4>
    <p>Date: {{ $mailData['prayer_date'] }}</p>
    <p>Email: {{ $mailData['prayer_email'] }}</p>
    <p>Phone Number: {{ $mailData['prayer_pnum'] }}</p>
    <p>Subject: {{ $mailData['prayer_request'] }}</p>

     
    <p>Thank you</p>
</body>
</html>