<!DOCTYPE HTML>
<html lang="en">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>LIVE TV</title>
	<meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
	


	
	
</head>
<body style="margin-left:10px;margin-right:10px;background-color:#234B84;">

<div style="width:100%;height:100%;">
    
  <h2 style="text-align:center;margin-top:70px;color:#fff;">LIVE TV</h2>
    
  <div style="margin-top:60px;">
 
  <iframe src="https://player.twitch.tv/?channel=AdeAjalaMinistriesTV&parent=aam.kccconline.org" frameborder="0" allowfullscreen="true" 
       scrolling="no"  height="400" width="100%"></iframe>
       
       <!--<iframe src="https://player.twitch.tv/?channel=moses1985&parent=aam.kccconline.org" frameborder="0" allowfullscreen="true" 
       scrolling="no"  height="400" width="100%"></iframe>-->
  </div>
</div>

	
</body>
</html>